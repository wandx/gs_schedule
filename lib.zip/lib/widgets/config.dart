const paddingLeft = 10.0;
const paddingRight = 10.0;
const paddingTop = 10.0;
const marginBottom = 10.0;
const inputHeight = 50.0;
